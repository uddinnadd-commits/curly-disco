package com.realistificator.client;

import com.realistificator.entity.PhysicsCell;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import org.joml.Quaternionf;

import java.util.List;

public class PhysicsBodyRenderState extends EntityRenderState {
    public List<PhysicsCell> cells = List.of();
    public Quaternionf rotation = new Quaternionf();
    public float comX, comY = 0.5f, comZ;
}
