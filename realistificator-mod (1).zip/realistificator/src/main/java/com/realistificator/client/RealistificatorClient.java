package com.realistificator.client;

import com.realistificator.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class RealistificatorClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.PHYSICS_BODY, PhysicsBodyRenderer::new);
    }
}
