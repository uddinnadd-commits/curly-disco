package com.realistificator.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Matrix3d;
import org.joml.Quaterniond;
import org.joml.Quaternionf;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * A rigid body made of unit-block cells: gravity, rotation, tumbling, friction, collisions with the world and
 * with other bodies, and shoving by entities.
 *
 * Frames: cells live on an integer lattice (cell (x,y,z) has its centre at lattice point (x, y+0.5, z)).
 * The entity position is the world position of the body's centre of mass; the world position of a lattice
 * point l is  P + R * (l - com).
 */
public class PhysicsBodyEntity extends Entity {
    public static final int MAX_CELLS = 64;

    private static final int SUBSTEPS = 4;
    private static final int PASSES = 2;
    private static final double GRAVITY = 0.04;
    private static final double SLOP = 0.005;
    private static final double FRICTION = 0.6;

    private static final EntityDataAccessor<String> DATA_CELLS =
            SynchedEntityData.defineId(PhysicsBodyEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Float> DATA_QX = SynchedEntityData.defineId(PhysicsBodyEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_QY = SynchedEntityData.defineId(PhysicsBodyEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_QZ = SynchedEntityData.defineId(PhysicsBodyEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_QW = SynchedEntityData.defineId(PhysicsBodyEntity.class, EntityDataSerializers.FLOAT);

    // shape
    private List<PhysicsCell> cells = new ArrayList<>();
    private double mass = 1.0, invMass = 1.0, radius = 1.0;
    private final Vector3d com = new Vector3d(0, 0.5, 0);
    private Matrix3d invILocal = new Matrix3d();
    private Matrix3d invIw = new Matrix3d();

    // state
    private final Quaterniond rot = new Quaterniond();
    private final Quaterniond prevRot = new Quaterniond();
    private boolean rotInitialised;
    private final Vector3d v = new Vector3d();
    private final Vector3d w = new Vector3d();
    private final Vector3d p = new Vector3d();
    private boolean asleep;
    private int restTicks;
    private int sleepCounter;
    private final Map<UUID, Vec3> lastPositions = new HashMap<>();

    public record Hit(int cellIndex, Direction face, Vec3 point) {}

    public PhysicsBodyEntity(EntityType<? extends PhysicsBodyEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true); // we apply our own gravity
        recomputeShape();
    }

    // ================================================================ cells / shape

    public List<PhysicsCell> getCells() {
        return cells;
    }

    public Vec3 getCom() {
        return new Vec3(com.x, com.y, com.z);
    }

    public boolean hasCell(int x, int y, int z) {
        for (PhysicsCell c : cells) {
            if (c.x() == x && c.y() == y && c.z() == z) return true;
        }
        return false;
    }

    public void setCells(List<PhysicsCell> newCells) {
        this.cells = new ArrayList<>(newCells);
        recomputeShape();
        if (!level().isClientSide()) {
            this.entityData.set(DATA_CELLS, encode(cells));
        }
        refreshBox();
    }

    /** Adds cells (given in lattice coordinates) while keeping every existing cell where it is in the world. */
    public void addCells(List<PhysicsCell> extra) {
        Vector3d oldCom = new Vector3d(com);
        List<PhysicsCell> all = new ArrayList<>(cells);
        all.addAll(extra);
        setCells(all);
        Vector3d shift = new Vector3d(com).sub(oldCom);
        rot.transform(shift);
        this.setPos(getX() + shift.x, getY() + shift.y, getZ() + shift.z);
        refreshBox();
        wake();
    }

    private void recomputeShape() {
        int n = Math.max(1, cells.size());
        mass = n;
        invMass = 1.0 / n;
        Vector3d c = new Vector3d();
        for (PhysicsCell cell : cells) c.add(cell.x(), cell.y() + 0.5, cell.z());
        if (cells.isEmpty()) c.set(0, 0.5, 0); else c.div(n);
        com.set(c);

        double ixx = 0, iyy = 0, izz = 0, ixy = 0, ixz = 0, iyz = 0, maxR = 0;
        double base = 1.0 / 6.0; // unit cube about its own centre
        if (cells.isEmpty()) { ixx = iyy = izz = base; }
        for (PhysicsCell cell : cells) {
            double rx = cell.x() - com.x, ry = cell.y() + 0.5 - com.y, rz = cell.z() - com.z;
            ixx += base + ry * ry + rz * rz;
            iyy += base + rx * rx + rz * rz;
            izz += base + rx * rx + ry * ry;
            ixy -= rx * ry; ixz -= rx * rz; iyz -= ry * rz;
            maxR = Math.max(maxR, Math.sqrt(rx * rx + ry * ry + rz * rz));
        }
        Matrix3d inertia = new Matrix3d().set(ixx, ixy, ixz, ixy, iyy, iyz, ixz, iyz, izz);
        invILocal = new Matrix3d(inertia).invert();
        radius = maxR + 0.87;
    }

    private void updateInvIw() {
        Matrix3d r = new Matrix3d().rotation(rot);
        invIw = new Matrix3d(r).mul(invILocal).mul(new Matrix3d(r).transpose());
    }

    // ================================================================ geometry helpers

    private Vector3d[] basis() {
        return new Vector3d[]{
                rot.transform(new Vector3d(1, 0, 0)),
                rot.transform(new Vector3d(0, 1, 0)),
                rot.transform(new Vector3d(0, 0, 1))};
    }

    private Obb makeObb(int cx, int cy, int cz, double px, double py, double pz, Vector3d[] b, double half) {
        double lx = cx - com.x, ly = cy + 0.5 - com.y, lz = cz - com.z;
        Vector3d centre = new Vector3d(px, py, pz).fma(lx, b[0]).fma(ly, b[1]).fma(lz, b[2]);
        return new Obb(centre, b, half, half, half);
    }

    /** World-space centre of the cell at the given lattice coordinates. */
    public Vec3 cellCenterWorld(int cx, int cy, int cz) {
        Vector3d l = new Vector3d(cx - com.x, cy + 0.5 - com.y, cz - com.z);
        rot.transform(l);
        return new Vec3(getX() + l.x, getY() + l.y, getZ() + l.z);
    }

    /** Converts a world point to lattice coordinates (cell centres are at integer x/z and y + 0.5). */
    public Vector3d worldToLattice(Vec3 world) {
        Vector3d l = new Vector3d(world.x - getX(), world.y - getY(), world.z - getZ());
        rot.transformInverse(l);
        return l.add(com);
    }

    public boolean cellBlocked(ServerLevel level, int cx, int cy, int cz) {
        Obb o = makeObb(cx, cy, cz, getX(), getY(), getZ(), basis(), 0.47);
        AABB area = new AABB(o.c.x - 1, o.c.y - 1, o.c.z - 1, o.c.x + 1, o.c.y + 1, o.c.z + 1);
        for (VoxelShape s : level.getBlockCollisions(null, area)) {
            for (AABB a : s.toAabbs()) {
                if (Obb.sat(o, Obb.ofAabb(a)) != null) return true;
            }
        }
        return false;
    }

    private AABB computeBox() {
        double x = getX(), y = getY(), z = getZ();
        if (cells.isEmpty()) return new AABB(x - 0.5, y - 0.5, z - 0.5, x + 0.5, y + 0.5, z + 0.5);
        Vector3d[] b = basis();
        double ex = 0.5 * (Math.abs(b[0].x) + Math.abs(b[1].x) + Math.abs(b[2].x));
        double ey = 0.5 * (Math.abs(b[0].y) + Math.abs(b[1].y) + Math.abs(b[2].y));
        double ez = 0.5 * (Math.abs(b[0].z) + Math.abs(b[1].z) + Math.abs(b[2].z));
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, minZ = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (PhysicsCell c : cells) {
            double lx = c.x() - com.x, ly = c.y() + 0.5 - com.y, lz = c.z() - com.z;
            double cx = x + b[0].x * lx + b[1].x * ly + b[2].x * lz;
            double cy = y + b[0].y * lx + b[1].y * ly + b[2].y * lz;
            double cz = z + b[0].z * lx + b[1].z * ly + b[2].z * lz;
            minX = Math.min(minX, cx - ex); maxX = Math.max(maxX, cx + ex);
            minY = Math.min(minY, cy - ey); maxY = Math.max(maxY, cy + ey);
            minZ = Math.min(minZ, cz - ez); maxZ = Math.max(maxZ, cz + ez);
        }
        return new AABB(minX, minY, minZ, maxX, maxY, maxZ);
    }

    /** setPos() resets the box to the entity-type size, so we re-apply ours after every move. */
    private void refreshBox() {
        this.setBoundingBox(computeBox());
    }

    /** Ray (segment) against the oriented cells. */
    public Optional<Hit> rayCast(Vec3 from, Vec3 to) {
        Vector3d a = worldToLattice(from);
        Vector3d bb = worldToLattice(to);
        Vec3 la = new Vec3(a.x, a.y, a.z), lb = new Vec3(bb.x, bb.y, bb.z);
        Hit best = null;
        double bestD = Double.MAX_VALUE;
        for (int i = 0; i < cells.size(); i++) {
            PhysicsCell c = cells.get(i);
            AABB box = new AABB(c.x() - 0.5, c.y(), c.z() - 0.5, c.x() + 0.5, c.y() + 1.0, c.z() + 0.5);
            Optional<Vec3> hit = box.clip(la, lb);
            if (hit.isEmpty()) continue;
            Vec3 h = hit.get();
            double d = h.distanceToSqr(la);
            if (d < bestD) {
                bestD = d;
                Vector3d wp = new Vector3d(h.x - com.x, h.y - com.y, h.z - com.z);
                rot.transform(wp);
                best = new Hit(i, faceOf(box, h), new Vec3(getX() + wp.x, getY() + wp.y, getZ() + wp.z));
            }
        }
        return Optional.ofNullable(best);
    }

    private static Direction faceOf(AABB box, Vec3 q) {
        double eps = 1.0E-3;
        if (Math.abs(q.x - box.minX) < eps) return Direction.WEST;
        if (Math.abs(q.x - box.maxX) < eps) return Direction.EAST;
        if (Math.abs(q.y - box.minY) < eps) return Direction.DOWN;
        if (Math.abs(q.y - box.maxY) < eps) return Direction.UP;
        if (Math.abs(q.z - box.minZ) < eps) return Direction.NORTH;
        return Direction.SOUTH;
    }

    /** Smoothed orientation for rendering. */
    public Quaternionf getRenderRotation(float partialTick) {
        Quaternionf a = new Quaternionf((float) prevRot.x, (float) prevRot.y, (float) prevRot.z, (float) prevRot.w);
        Quaternionf b = new Quaternionf((float) rot.x, (float) rot.y, (float) rot.z, (float) rot.w);
        return a.slerp(b, partialTick);
    }

    // ================================================================ sync + save

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_CELLS, "");
        builder.define(DATA_QX, 0f);
        builder.define(DATA_QY, 0f);
        builder.define(DATA_QZ, 0f);
        builder.define(DATA_QW, 1f);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> accessor) {
        super.onSyncedDataUpdated(accessor);
        if (DATA_CELLS.equals(accessor) && level().isClientSide()) {
            this.cells = decode(this.entityData.get(DATA_CELLS));
            recomputeShape();
            refreshBox();
        }
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        double qx = input.getDoubleOr("RotX", 0.0), qy = input.getDoubleOr("RotY", 0.0);
        double qz = input.getDoubleOr("RotZ", 0.0), qw = input.getDoubleOr("RotW", 1.0);
        rot.set(qx, qy, qz, qw);
        if (rot.lengthSquared() < 1.0E-6) rot.identity(); else rot.normalize();
        prevRot.set(rot);
        syncRotation();
        setCells(input.read("Cells", PhysicsCell.CODEC.listOf()).orElse(List.of()));
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        output.store("Cells", PhysicsCell.CODEC.listOf(), cells);
        output.putDouble("RotX", rot.x);
        output.putDouble("RotY", rot.y);
        output.putDouble("RotZ", rot.z);
        output.putDouble("RotW", rot.w);
    }

    private void syncRotation() {
        this.entityData.set(DATA_QX, (float) rot.x);
        this.entityData.set(DATA_QY, (float) rot.y);
        this.entityData.set(DATA_QZ, (float) rot.z);
        this.entityData.set(DATA_QW, (float) rot.w);
    }

    // Block-state ids are only used for the live network sync (same registry on both ends).
    private static String encode(List<PhysicsCell> list) {
        StringBuilder sb = new StringBuilder();
        for (PhysicsCell c : list) {
            sb.append(c.x()).append(',').append(c.y()).append(',').append(c.z()).append(',')
              .append(Block.getId(c.state())).append(';');
        }
        return sb.toString();
    }

    private static List<PhysicsCell> decode(String s) {
        List<PhysicsCell> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        for (String part : s.split(";")) {
            if (part.isEmpty()) continue;
            String[] f = part.split(",");
            if (f.length != 4) continue;
            try {
                BlockState state = Block.stateById(Integer.parseInt(f[3]));
                out.add(new PhysicsCell(Integer.parseInt(f[0]), Integer.parseInt(f[1]), Integer.parseInt(f[2]), state));
            } catch (NumberFormatException ignored) {
            }
        }
        return out;
    }

    // ================================================================ interaction

    @Override
    public boolean isPickable() {
        return true;
    }

    /** Punching a body whacks it where you hit it: off-centre hits make it spin and tumble. */
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        Entity attacker = source.getEntity();
        if (attacker == null) return false;
        Vec3 eye = attacker.getEyePosition();
        Vec3 look = attacker.getLookAngle();
        Optional<Hit> hit = rayCast(eye, eye.add(look.scale(6.0)));
        Vec3 at = hit.map(Hit::point).orElse(position());
        double k = 0.8 * Math.sqrt(mass);
        applyImpulse(new Vector3d(look.x * k, look.y * k + 0.2 * k, look.z * k), new Vector3d(at.x, at.y, at.z));
        return true;
    }

    public void wake() {
        asleep = false;
        restTicks = 0;
        sleepCounter = 0;
    }

    /** Applies a momentum impulse J at a world-space point. */
    public void applyImpulse(Vector3d impulse, Vector3d worldPoint) {
        wake();
        updateInvIw();
        Vector3d r = new Vector3d(worldPoint).sub(getX(), getY(), getZ());
        v.fma(invMass, impulse);
        Vector3d torque = new Vector3d(r).cross(impulse);
        invIw.transform(torque);
        w.add(torque);
    }

    // ================================================================ physics

    @Override
    public void tick() {
        super.tick();
        try {
            if (level() instanceof ServerLevel sl) {
                serverPhysics(sl);
                sanitize();
            } else {
                clientRotationTick();
            }
            refreshBox();
        } catch (Exception ex) {
            onPhysicsError(ex);
        }
    }

    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger("realistificator");
    private boolean errorLogged;

    /** Never let a physics bug crash the game: log it once, calm the body down and carry on. */
    private void onPhysicsError(Exception ex) {
        if (!errorLogged) {
            errorLogged = true;
            LOGGER.error("Realistificator physics error (ignored, body put to sleep)", ex);
        }
        v.zero();
        w.zero();
        asleep = true;
        sleepCounter = 0;
        sanitize();
        try {
            refreshBox();
        } catch (Exception ignored) {
        }
    }

    /** Repairs NaN/infinite values so one bad step can't permanently break (or hide) a body. */
    private void sanitize() {
        boolean bad = !Double.isFinite(rot.x) || !Double.isFinite(rot.y) || !Double.isFinite(rot.z)
                || !Double.isFinite(rot.w) || rot.lengthSquared() < 1.0E-6;
        if (bad) rot.identity();
        if (!Double.isFinite(v.x) || !Double.isFinite(v.y) || !Double.isFinite(v.z)) v.zero();
        if (!Double.isFinite(w.x) || !Double.isFinite(w.y) || !Double.isFinite(w.z)) w.zero();
        if (!Double.isFinite(getX()) || !Double.isFinite(getY()) || !Double.isFinite(getZ())) {
            if (Double.isFinite(p.x) && Double.isFinite(p.y) && Double.isFinite(p.z)) setPos(p.x, p.y, p.z);
            else discard();
        }
    }

    private void clientRotationTick() {
        prevRot.set(rot);
        rot.set(entityData.get(DATA_QX), entityData.get(DATA_QY), entityData.get(DATA_QZ), entityData.get(DATA_QW));
        if (rot.lengthSquared() < 1.0E-6) rot.identity(); else rot.normalize();
        if (!rotInitialised) {
            prevRot.set(rot);
            rotInitialised = true;
        }
    }

    private void serverPhysics(ServerLevel level) {
        if (cells.isEmpty() || getY() < -128) {
            this.discard();
            return;
        }
        pushByEntities(level);
        if (asleep) {
            // re-check support every second in case the blocks underneath were removed
            if (++sleepCounter < 20) return;
            asleep = false;
            restTicks = 10;
            sleepCounter = 0;
        }

        p.set(getX(), getY(), getZ());
        boolean inWater = level.getFluidState(BlockPos.containing(p.x, p.y, p.z)).is(FluidTags.WATER);

        double reach = radius + v.length() + 1.0;
        AABB area = new AABB(p.x - reach, p.y - reach, p.z - reach, p.x + reach, p.y + reach, p.z + reach);
        List<AABB> worldBoxes = new ArrayList<>();
        for (VoxelShape s : level.getBlockCollisions(this, area)) worldBoxes.addAll(s.toAabbs());
        List<PhysicsBodyEntity> others = level.getEntitiesOfClass(PhysicsBodyEntity.class, area, e -> e != this);
        for (PhysicsBodyEntity o : others) o.updateInvIw();

        clampVelocities();
        double h = 1.0 / SUBSTEPS;
        for (int step = 0; step < SUBSTEPS; step++) {
            v.y -= (inWater ? 0.01 : GRAVITY) * h;
            if (inWater) { v.mul(Math.pow(0.9, h)); w.mul(Math.pow(0.9, h)); }

            p.fma(h, v);
            if (w.lengthSquared() > 1.0E-12) {
                Quaterniond dq = new Quaterniond(w.x * h * 0.5, w.y * h * 0.5, w.z * h * 0.5, 0).mul(rot);
                rot.add(dq).normalize();
            }
            updateInvIw();

            for (int pass = 0; pass < PASSES; pass++) {
                Vector3d[] b = basis();
                for (PhysicsCell cell : cells) {
                    // world boxes
                    for (AABB wb : worldBoxes) {
                        Obb a = makeObb(cell.x(), cell.y(), cell.z(), p.x, p.y, p.z, b, 0.5);
                        if (sphereMissesBox(a.c, wb)) continue;
                        resolve(a, Obb.ofAabb(wb), null);
                    }
                    // other bodies
                    for (PhysicsBodyEntity o : others) {
                        Vector3d[] ob = o.basis();
                        for (PhysicsCell oc : o.cells) {
                            Obb a = makeObb(cell.x(), cell.y(), cell.z(), p.x, p.y, p.z, b, 0.5);
                            Obb bo = o.makeObb(oc.x(), oc.y(), oc.z(), o.getX(), o.getY(), o.getZ(), ob, 0.5);
                            if (a.c.distanceSquared(bo.c) > 3.0) continue;
                            resolve(a, bo, o);
                        }
                    }
                }
            }
            clampVelocities();
        }

        // damping
        v.mul(0.995);
        w.mul(0.985);

        this.setPos(p.x, p.y, p.z);
        syncRotation();

        if (v.lengthSquared() < 1.0E-4 && w.lengthSquared() < 1.0E-4) {
            if (++restTicks >= 15) {
                v.zero();
                w.zero();
                asleep = true;
                sleepCounter = 0;
            }
        } else {
            restTicks = 0;
        }
    }

    private void clampVelocities() {
        double s = v.length();
        if (s > 2.0) v.mul(2.0 / s);
        double a = w.length();
        if (a > 0.6) w.mul(0.6 / a);
    }

    private static boolean sphereMissesBox(Vector3d c, AABB b) {
        double dx = Math.max(Math.max(b.minX - c.x, 0), c.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - c.y, 0), c.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - c.z, 0), c.z - b.maxZ);
        return dx * dx + dy * dy + dz * dz > 0.76;
    }

    /** Resolves one cell-vs-box overlap: position push-out plus normal and friction impulses at each contact point. */
    private void resolve(Obb a, Obb b, PhysicsBodyEntity other) {
        Obb.Sat sat = Obb.sat(a, b);
        if (sat == null) return;
        Vector3d n = sat.normal();
        List<Vector3d> points = Obb.contactPoints(a, b, n);

        double corr = Math.min(Math.max(sat.depth() - SLOP, 0.0), 0.4) * (other == null ? 1.0 : 0.5);
        p.fma(corr, n);
        if (other != null) other.wake();

        Vector3d centreA = new Vector3d(p); // after push-out
        for (Vector3d pt : points) {
            Vector3d rA = new Vector3d(pt).sub(centreA);
            Vector3d rB = other == null ? null : new Vector3d(pt).sub(other.getX(), other.getY(), other.getZ());

            Vector3d vrel = velocityAt(rA, this);
            if (other != null) vrel.sub(velocityAt(rB, other));
            double vn = vrel.dot(n);
            if (vn >= 0) continue;

            double k = effectiveMass(rA, n, this) + (other == null ? 0 : effectiveMass(rB, n, other));
            double e = vn < -0.15 ? 0.25 : 0.0;
            double j = -(1.0 + e) * vn / k;
            impulseOn(this, n, j, rA);
            if (other != null) impulseOn(other, n, -j, rB);

            // friction
            vrel = velocityAt(rA, this);
            if (other != null) vrel.sub(velocityAt(rB, other));
            Vector3d vt = new Vector3d(vrel).fma(-vrel.dot(n), n);
            double vtLen = vt.length();
            if (vtLen > 1.0E-6) {
                Vector3d t = vt.div(vtLen);
                double kt = effectiveMass(rA, t, this) + (other == null ? 0 : effectiveMass(rB, t, other));
                double jt = Math.min(vtLen / kt, FRICTION * j);
                impulseOn(this, t, -jt, rA);
                if (other != null) impulseOn(other, t, jt, rB);
            }
        }
    }

    private static Vector3d velocityAt(Vector3d r, PhysicsBodyEntity body) {
        return new Vector3d(body.w).cross(r).add(body.v);
    }

    private static double effectiveMass(Vector3d r, Vector3d dir, PhysicsBodyEntity body) {
        Vector3d rn = new Vector3d(r).cross(dir);
        body.invIw.transform(rn);
        rn.cross(r);
        return body.invMass + rn.dot(dir);
    }

    private static void impulseOn(PhysicsBodyEntity body, Vector3d dir, double j, Vector3d r) {
        body.v.fma(j * body.invMass, dir);
        Vector3d torque = new Vector3d(r).cross(dir).mul(j);
        body.invIw.transform(torque);
        body.w.add(torque);
    }

    /** Living entities that overlap the body and are walking into it transfer their speed to it. */
    private void pushByEntities(ServerLevel level) {
        Map<UUID, Vec3> next = new HashMap<>();
        double massFactor = Math.max(0.3, 1.0 / Math.sqrt(mass));
        Vector3d[] b = basis();

        List<Entity> nearby = level.getEntities(this, getBoundingBox().inflate(0.6, 0.0, 0.6),
                e -> e instanceof LivingEntity && !e.isSpectator());
        for (Entity e : nearby) {
            Vec3 now = e.position();
            next.put(e.getUUID(), now);
            Vec3 before = lastPositions.get(e.getUUID());
            if (before == null) continue;

            AABB eb = e.getBoundingBox();
            Obb eo = Obb.ofAabb(eb);
            for (PhysicsCell cell : cells) {
                Obb co = makeObb(cell.x(), cell.y(), cell.z(), getX(), getY(), getZ(), b, 0.5);
                Obb.Sat sat = Obb.sat(eo, co); // normal: cell -> entity
                if (sat == null) continue;
                double dx = -sat.normal().x, dz = -sat.normal().z; // entity -> body, horizontal
                double len = Math.sqrt(dx * dx + dz * dz);
                if (len < 0.25) continue; // standing on top of / under it
                dx /= len; dz /= len;

                double toward = (now.x - before.x) * dx + (now.z - before.z) * dz;
                if (toward > 0.003) {
                    double target = toward * 1.1 * massFactor;
                    double cur = v.x * dx + v.z * dz;
                    if (cur < target) {
                        double dv = target - cur;
                        Vector3d J = new Vector3d(dx * dv * mass * 0.7, 0, dz * dv * mass * 0.7);
                        applyImpulse(J, new Vector3d(e.getX(), e.getY() + 0.5, e.getZ()));
                    }
                }
                break;
            }
        }
        lastPositions.clear();
        lastPositions.putAll(next);
    }
}
