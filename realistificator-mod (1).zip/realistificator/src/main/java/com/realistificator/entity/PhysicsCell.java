package com.realistificator.entity;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.world.level.block.state.BlockState;

/** One block of a physics body, positioned on an integer lattice relative to the body's origin cell. */
public record PhysicsCell(int x, int y, int z, BlockState state) {
    public static final Codec<PhysicsCell> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.fieldOf("x").forGetter(PhysicsCell::x),
            Codec.INT.fieldOf("y").forGetter(PhysicsCell::y),
            Codec.INT.fieldOf("z").forGetter(PhysicsCell::z),
            BlockState.CODEC.fieldOf("state").forGetter(PhysicsCell::state)
    ).apply(i, PhysicsCell::new));
}
