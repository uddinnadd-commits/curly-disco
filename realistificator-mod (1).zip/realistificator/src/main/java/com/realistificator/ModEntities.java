package com.realistificator;

import com.realistificator.entity.PhysicsBodyEntity;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    private static final ResourceKey<EntityType<?>> PHYSICS_BODY_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(Realistificator.MOD_ID, "physics_body"));

    public static final EntityType<PhysicsBodyEntity> PHYSICS_BODY = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            PHYSICS_BODY_KEY,
            EntityType.Builder.<PhysicsBodyEntity>of(PhysicsBodyEntity::new, MobCategory.MISC)
                    .sized(1.0f, 1.0f)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .build(PHYSICS_BODY_KEY));

    private ModEntities() {}

    public static void init() {
        // touching the class registers the entity type
    }
}
